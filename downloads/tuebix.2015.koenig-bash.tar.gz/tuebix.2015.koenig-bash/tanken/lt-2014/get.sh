#!/bin/bash

wget -q 'http://www.spritpreismonitor.de/suche/?tx_spritpreismonitor_pi1[searchRequest][plzOrtGeo]=Berlin&tx_spritpreismonitor_pi1[searchRequest][umkreis]=10&tx_spritpreismonitor_pi1[searchRequest][kraftstoffart]=diesel&tx_spritpreismonitor_pi1[searchRequest][tankstellenbetreiber]=' -O -  |
grep mtsk_id  |
tr '{}' '\n'  |
grep mtsk_id |
sed -e 's/","/"\n"/g' |
sed   -e s/:/=/ -e  's/"//'  -e   's/"//'   |
while read l ; do  
    eval $l  
    if [[ "$l" == *entfernung* ]] ; then 
	grep -q "$diesel $datum" id/$mtsk_id || echo $diesel $datum >> id/$mtsk_id 
	echo $laengengrad $breitengrad $name $strasse $hausnr $plz $ort $entfernung > ad/$mtsk_id 
    fi
done 
