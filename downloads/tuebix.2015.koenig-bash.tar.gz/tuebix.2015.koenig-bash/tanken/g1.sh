#!/bin/bash

mkdir -p ad id data

date=`date +%Y-%m-%d_%H:%M:%S`

(
    # ort3=48.291396%2C8.853011
    for ort in 72336 72070 14055 15711 ; do   ## 48.291396%2C8.853011
	wget 'http://www.spritpreismonitor.de/suche/?tx_spritpreismonitor_pi1[__referrer][%40extension]=Spritpreismonitor&tx_spritpreismonitor_pi1[__referrer][%40controller]=Search&tx_spritpreismonitor_pi1[__referrer][%40action]=search&tx_spritpreismonitor_pi1[__referrer][arguments]=YToxOntzOjEzOiJzZWFyY2hSZXF1ZXN0IjthOjQ6e3M6OToicGx6T3J0R2VvIjtzOjU6IjcyMzM2IjtzOjc6InVta3JlaXMiO3M6MToiNSI7czoxMzoia3JhZnRzdG9mZmFydCI7czo2OiJkaWVzZWwiO3M6MjA6InRhbmtzdGVsbGVuYmV0cmVpYmVyIjtzOjE6IjAiO319ba7c2e5c9be569408a9d9166aaa14f1230ea9f8f&tx_spritpreismonitor_pi1[__trustedProperties]=a%3A1%3A{s%3A13%3A%22searchRequest%22%3Ba%3A4%3A{s%3A9%3A%22plzOrtGeo%22%3Bi%3A1%3Bs%3A7%3A%22umkreis%22%3Bi%3A1%3Bs%3A13%3A%22kraftstoffart%22%3Bi%3A1%3Bs%3A20%3A%22tankstellenbetreiber%22%3Bi%3A1%3B}}70105c454eba16faccbf2bd6908bb12cb155d4ee&tx_spritpreismonitor_pi1[searchRequest][plzOrtGeo]='"$ort"'&tx_spritpreismonitor_pi1[searchRequest][umkreis]=25&tx_spritpreismonitor_pi1[searchRequest][kraftstoffart]=diesel&tx_spritpreismonitor_pi1[searchRequest][tankstellenbetreiber]=0' -O- -q 
    done
) |
tee data/data.spritpreismonitor.$date |
tr '{' '\012' | 
grep mtsk_id | 
sort -t\" -k48 -n | 
tr ',}'  ' \012' | 
sed 's/"\([^"]*\)":/\1=/g' | 
grep = | 
sort -u | 
sed 's/\\/\\\\/g' |
while read l ; do 
    eval $l 
    ( 
	cat id/$mtsk_id 2> /dev/null
	echo $datum $diesel 
    ) | sort -u  > $$ 
    cmp -s $$ id/$mtsk_id  || { mv $$ id/$mtsk_id ; echo "$l" | sed 's/" /"@/g' | tr @ '\012' > ad/$mtsk_id ; }
done 

rm -f $$

xz data/data.spritpreismonitor.$date
