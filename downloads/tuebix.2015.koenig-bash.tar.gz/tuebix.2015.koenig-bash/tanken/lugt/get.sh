#!/bin/bash

for ort in 72070 72336  70195 ; do 
    # ort=72070
    km=10

wget "http://www.spritpreismonitor.de/suche/?tx_spritpreismonitor_pi1[searchRequest][plzOrtGeo]=$ort&tx_spritpreismonitor_pi1[searchRequest][umkreis]=$km&tx_spritpreismonitor_pi1[searchRequest][kraftstoffart]=diesel&tx_spritpreismonitor_pi1[searchRequest][tankstellenbetreiber]=" -O- 
done| 
grep spmResult  | 
tr , '\012' | 
tr -d '"{}'  | 
while read L ; do 
    case "$L" in 
	*diesel*) preis=$L ; txt="${datum#*:} ${preis#*:}" fn=${id#*:}
	    ; grep -q "$txt" "$fn" || echo "$txt" >> "$fn" ;; 
	*datum*)  datum=$L ;; 
	*mtsk_id*) id=$L ;; 
    esac  
done

