#!/bin/bash

mkdir -p daten

# cat O1 |

wget 'http://www.oeamtc.at/um-webapp/login?app=sprit-search&ZIP=&selectedFuelType=diesel&state=Vorarlberg&spritaction=doSimpleSearch&daysLimit=sinceNoon' -O - 2> /dev/null |
tr -d '\012' |
sed 's/;jsessionid/jsessionid/g' |
tr ';\011' '\012 ' |
tr -s ' \011' |
egrep 'gasStation\(|addFuel' |
sed 's/)$//' |
tr ',' ' ' |
while read l ; do 
    eval set -- ${l#*( }
	if [[ "$l" == *gasStation* ]] ; then
	    id=$1 name=$2 url=$3 e=$4 n=$5 str=$6 ort=$7 
	fi
	if [[ "$l" == *addFuel* ]] ; then
	    nr=$1 fuel=$2 preis=$3 datum=$4 rest=$5

	    #    grep -q "$datum" daten/$id || echo $preis $datum $n $e $name $str $ort >> daten/$id
	    tail -1 daten/$id 2> /dev/null | grep -q "^$preis " || echo $preis $datum $n $e $name $str $ort >> daten/$id
	fi
done
