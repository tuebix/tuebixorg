#!/bin/bash

# wget 'http://www.oeamtc.at/um-webapp/login?app=sprit-search&ZIP=&selectedFuelType=diesel&state=Vorarlberg&spritaction=doSimpleSearch&daysLimit=sinceNoon' -O - |  
# cat O1 | 

mkdir -p daten

(
    wget 'http://www.oeamtc.at/um-webapp/login?app=sprit-search&ZIP=&selectedFuelType=diesel&state=Vorarlberg&spritaction=doSimpleSearch&daysLimit=sinceNoon' -O - |  
    awk '
	/tmpGS = new gasStation/{l=$0}
	/tmpGS.addFuel/{getline;getline;getline;preis=$1;getline;date=$0; print preis,date,l}
	' | 
    sed -e 's/tmpGS = new gasStation(//' -e  's/);//'  | 
    tr ','    ' ' | 
    recode latin1..utf8 |
    while read l  ; do 
	eval set -- $l 
	preis=$1 datum=$2 id=$3 name=$4 url=$5 e=$6 n=$7 str=$8 ort=$9 
	
	#    grep -q "$datum" daten/$id || echo $preis $datum $n $e $name $str $ort >> daten/$id
	tail -1 daten/$id  | grep -q "^$preis " || echo $preis $datum $n $e $name $str $ort >> daten/$id
    done

) 2> /dev/null
