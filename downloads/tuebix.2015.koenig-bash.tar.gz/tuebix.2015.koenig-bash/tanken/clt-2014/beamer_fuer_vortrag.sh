xrandr --output LVDS1 --mode 1024x768 --output VGA1 --mode 1024x768
