#!/bin/bash

km=10

for ort in Chemnitz Dresden Balingen ; do 

wget 2> /dev/null  "http://www.spritpreismonitor.de/suche/?tx_spritpreismonitor_pi1[searchRequest][plzOrtGeo]=$ort%2C+Sachsen&tx_spritpreismonitor_pi1[searchRequest][umkreis]=$km&tx_spritpreismonitor_pi1[searchRequest][kraftstoffart]=diesel&tx_spritpreismonitor_pi1[searchRequest][tankstellenbetreiber]="  -O -  |
grep spmResult  |
tr '{}' '\012' |
grep mtsk_id  |
sed 's/","/"\n"/g' |
sed -e 's/^"//' -e 's/":"/:"/' -e s/:/=/ |
while  read l  ; do  
    eval $l 
    if [[ "$l" == entfernung* ]] ;  then 
	grep -q "^$diesel $datum" $mtsk_id  || 
	echo $diesel $datum  $entfernung $breitengrad $laengengrad $name >> id/$mtsk_id ; 
    fi 
done  

done
